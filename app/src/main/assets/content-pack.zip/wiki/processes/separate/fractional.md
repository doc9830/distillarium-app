---
id: processes/separate/fractional
title: Дробная перегонка
short: Дробная перегонка — это разделение спирта на фракции по температуре кипения.
category: tehnologii
created: 2026-09-05
updated: 2026-09-05
sources: []
source: moonshinewiki
source_slug: drobnaya-peregonka
---
Дробная перегонка — это разделение спирта на фракции по температуре кипения.

- Медленный нагрев.
- Отбор по каплям на этапе голов.
- Чёткое разделение тела и хвостов.

Это ключевая технология качественного [[processes/separate/heads-hearts-tails|самогона]].
