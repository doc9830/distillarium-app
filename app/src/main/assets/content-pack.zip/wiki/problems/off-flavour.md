---
id: problems/off-flavour
title: Неприятный запах
short: Неприятный запах обычно вызван сивушными маслами или неправильным отбором фракций.
category: problemy-i-resheniya
created: 2026-09-05
updated: 2026-09-05
sources: []
source: moonshinewiki
source_slug: nepriyatnyy-zapah
---
Неприятный запах обычно вызван сивушными маслами или неправильным отбором фракций.

- Повторная дробная перегонка.
- Отбор голов и хвостов.
- Очистка углём.

Правильный [[processes/separate/heads-hearts-tails|отбор фракций]] решает большинство проблем с запахом.
