---
id: problems/low-abv
title: Низкая крепость
short: "Низкая крепость самогона возможна при:"
category: problemy-i-resheniya
created: 2026-09-05
updated: 2026-09-05
sources: []
source: moonshinewiki
source_slug: nizkaya-krepost
---
Низкая крепость самогона возможна при:

- неполном выбраживании;
- неправильной перегонке;
- слабом охлаждении.

Проверьте затор ареометром и повторите [[processes/separate/second-run-pot|перегонку]].
