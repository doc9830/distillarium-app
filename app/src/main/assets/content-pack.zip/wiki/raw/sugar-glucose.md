---
id: raw/sugar-glucose
title: Сахар и глюкоза
short: Основа большинства браг — сахар.
category: ingredienty
created: 2026-09-05
updated: 2026-09-05
sources: []
source: moonshinewiki
source_slug: sahar-i-glyukoza
---
Основа большинства браг — сахар.

- Обычный сахар — доступен и понятен.
- Глюкоза бродит чище.
- Инвертный сироп ускоряет брожение.

См. [[recipes/sugar-wash-classic|классическая сахарная бага]].
